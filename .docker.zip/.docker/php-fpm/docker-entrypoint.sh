#!/bin/sh
# vim:sw=4:ts=4:et

set -e
chmod -R 0755 /docker-entrypoint.d/

if [ "$1" = "docker-php-entrypoint" -o "$1" = "php-fpm" ]; then
    if /usr/bin/find "/docker-entrypoint.d/" -mindepth 1 -maxdepth 1 -type f -print -quit 2>/dev/null | read v; then
        echo "$0: /docker-entrypoint.d/ is not empty, will attempt to perform configuration" >&2

        echo "$0: Looking for shell scripts in /docker-entrypoint.d/" >&2
        find "/docker-entrypoint.d/" -follow -type f -print | sort -V | while read -r f; do
            case "$f" in
                *.sh)
                    if [ -x "$f" ]; then
                        echo "$0: Launching $f" >&2;
                        "$f"
                    else
                        # warn on shell scripts without exec bit
                        echo "$0: Ignoring $f, not executable" >&2;
                    fi
                    ;;
                *) echo "$0: Ignoring $f" >&2;;
            esac
        done

        echo "$0: Configuration complete; ready for start up" >&2
    else
        echo "$0: No files found in /docker-entrypoint.d/, skipping configuration" >&2
    fi
fi

echo "Execute: $@" >&2

exec "$@";

# while true; do
# 	sleep 3
# done;