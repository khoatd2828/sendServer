#!/bin/sh
set -e

CUR_DIR="/docker-entrypoint.d"
FILE_HOSTS="$CUR_DIR/hosts.txt"
TMP_HOSTS="$CUR_DIR/tmp.txt"
ORI_HOSTS=/etc/hosts.tmp
LINK_HOSTS=/usr/local/bin/add-hosts

IP=${1:-'172.21.0.6'}
echo "IP '$IP'" >&2

if [ ! -e $LINK_HOSTS ]; then
	ln -s $CUR_DIR/add-hosts.sh $LINK_HOSTS
	chmod +x $LINK_HOSTS
	echo "Not found link" >&2;
else
	echo "Found link $LINK_HOSTS" >&2;
fi

if [ ! -f $ORI_HOSTS ]; then
	cp /etc/hosts $ORI_HOSTS
	echo "Not found backup hosts $ORI_HOSTS" >&2;
else
	echo "Found backup hosts $ORI_HOSTS" >&2;
fi

if [ -f $FILE_HOSTS ]; then
	echo "Exits hosts: $FILE_HOSTS" >&2
	cp $FILE_HOSTS $TMP_HOSTS

	# Lay IP tu service NGINX                      ping -w 1 -W 5 nginx
	# Lay IP tu nhieu dong text:                   grep -P '(\d+\.\d+\.\d+\.\d+)' -o
	# Lay 1 IP dau tien cua nhieu dong text IP:    sed -nE '1 s/(.*)/\1/p'
	# Tao Regular Expression cho chuoi IP:         sed -e 's/\./\\\./g'
	# Replace chuoi NGINX_IP thanh IP trich xuat ra duoc trong file:      sed -i 's/NGINX_IP/'$REGX_IP'/g' $TMP_HOSTS
	#LINES=`ping -w 1 -W 5 nginx | grep -P '(\d+\.\d+\.\d+\.\d+)' -o`
	#echo "Lines $LINES" >&2

	#IP=`ping -w 1 -W 5 nginx | grep -P '(\d+\.\d+\.\d+\.\d+)' -o | sed -nE '1 s/(.*)/\1/p'`
	#IP=${1:-'172.21.0.5'}
	#echo "IP '$IP'" >&2

	REGX_IP=`echo $IP | sed -e 's/\./\\\./g'`
	echo "Regular IP: '$REGX_IP'" >&2

	echo "sed -i 's/NGINX_IP/'$REGX_IP'/g' '$TMP_HOSTS'" >&2
	sed -i 's/NGINX_IP/'$REGX_IP'/g' $TMP_HOSTS

	# cat $TMP_HOSTS >&2
	cat $ORI_HOSTS > /etc/hosts
	cat $TMP_HOSTS >> /etc/hosts
	rm $TMP_HOSTS
	cat /etc/hosts >&2
	echo "\n" >&2
else
	echo "No exits hosts: $FILE_HOSTS" >&2
fi

# ls -la $CUR_DIR >&2
# docker inspect -f '{{range.NetworkSettings.Networks}}{{.IPAddress}}{{end}}' container_name_or_id

